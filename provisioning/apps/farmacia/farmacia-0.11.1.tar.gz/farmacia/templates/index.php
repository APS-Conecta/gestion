<?php
declare(strict_types=1);
/** The SPA host: everything renders inside this one mount point. */
?>
<div id="farmacia"></div>