<?php

declare(strict_types=1);

/**
 * SPDX-FileCopyrightText: 2018 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

namespace OCA\GroupFolders\Versions;

use OC\Files\Storage\Storage;
use OCA\DAV\Connector\Sabre\Exception\Forbidden;
use OCA\Files_Versions\Versions\IDeletableVersionBackend;
use OCA\Files_Versions\Versions\IMetadataVersion;
use OCA\Files_Versions\Versions\IMetadataVersionBackend;
use OCA\Files_Versions\Versions\INeedSyncVersionBackend;
use OCA\Files_Versions\Versions\IVersion;
use OCA\Files_Versions\Versions\IVersionBackend;
use OCA\Files_Versions\Versions\IVersionsImporterBackend;
use OCA\GroupFolders\Folder\FolderDefinition;
use OCA\GroupFolders\Folder\FolderDefinitionWithMappings;
use OCA\GroupFolders\Folder\FolderDefinitionWithPermissions;
use OCA\GroupFolders\Folder\FolderWithMappingsAndCache;
use OCA\GroupFolders\Mount\GroupFolderStorage;
use OCA\GroupFolders\Mount\GroupMountPoint;
use OCA\GroupFolders\Mount\MountProvider;
use OCP\AppFramework\Db\DoesNotExistException;
use OCP\Constants;
use OCP\Files\File;
use OCP\Files\FileInfo;
use OCP\Files\Folder;
use OCP\Files\IMimeTypeLoader;
use OCP\Files\IRootFolder;
use OCP\Files\Mount\IMountManager;
use OCP\Files\Node;
use OCP\Files\NotFoundException;
use OCP\Files\NotPermittedException;
use OCP\Files\Storage\IStorage;
use OCP\Files\Storage\IStorageFactory;
use OCP\IUser;
use OCP\IUserSession;
use Psr\Log\LoggerInterface;
use RuntimeException;

class VersionsBackend implements IVersionBackend, IMetadataVersionBackend, IDeletableVersionBackend, INeedSyncVersionBackend, IVersionsImporterBackend {
	public function __construct(
		private readonly IRootFolder $rootFolder,
		private readonly MountProvider $mountProvider,
		private readonly LoggerInterface $logger,
		private readonly GroupVersionsMapper $groupVersionsMapper,
		private readonly IMimeTypeLoader $mimeTypeLoader,
		private readonly IUserSession $userSession,
		private readonly IMountManager $mountManager,
		private readonly IStorageFactory $storageFactory,
	) {
	}

	public function useBackendForStorage(IStorage $storage): bool {
		return true;
	}

	private function getFolderForFile(FileInfo $file): FolderDefinition {
		$storage = $file->getStorage();
		$mountPoint = $file->getMountPoint();

		// getting it from the mountpoint is more efficient
		if ($mountPoint instanceof GroupMountPoint) {
			return $mountPoint->getFolder();
		} elseif ($storage->instanceOfStorage(GroupFolderStorage::class)) {
			/** @var GroupFolderStorage $storage */
			return $storage->getFolder();
		}

		throw new \LogicException('Team folder version backend called for non Team folder file');
	}

	public function getVersionFolderForFile(FileInfo $file): Folder {
		$folder = $this->getFolderForFile($file);
		$groupFoldersVersionsFolder = $this->getVersionsFolder($folder);

		try {
			/** @var Folder $versionsFolder */
			$versionsFolder = $groupFoldersVersionsFolder->get((string)$file->getId());

			return $versionsFolder;
		} catch (NotFoundException) {
			// The folder for the file's versions might not exists if no versions has been create yet.
			return $groupFoldersVersionsFolder->newFolder((string)$file->getId());
		}
	}

	/**
	 * @return GroupVersion[]
	 */
	public function getVersionsForFile(IUser $user, FileInfo $file): array {
		$versionsFolder = $this->getVersionFolderForFile($file);

		try {
			$versions = $this->getVersionsForFileFromDB($file, $user);

			// Early exit if we find any version in the database.
			// Else we continue to populate the DB from what's on disk.
			if (count($versions) > 0) {
				return $versions;
			}

			// Insert the entry in the DB for the current version.
			$versionEntity = new GroupVersionEntity();
			$fileId = $file->getId();
			if ($fileId === null) {
				throw new RuntimeException('Failed to get id of file.');
			}
			$versionEntity->setFileId($fileId);
			$versionEntity->setTimestamp($file->getMTime());
			$versionEntity->setSize($file->getSize());
			$versionEntity->setMimetype($this->mimeTypeLoader->getId($file->getMimetype()));
			$versionEntity->setDecodedMetadata([]);
			$this->groupVersionsMapper->insert($versionEntity);

			// Insert entries in the DB for existing versions.
			$versionsOnFS = $versionsFolder->getDirectoryListing();
			foreach ($versionsOnFS as $version) {
				if ($version instanceof Folder) {
					$this->logger->error('Found an unexpected subfolder inside the Team folder version folder.');
				}

				$versionEntity = new GroupVersionEntity();
				$fileId = $file->getId();
				if ($fileId === null) {
					throw new RuntimeException('Failed to get id of file.');
				}
				$versionEntity->setFileId($fileId);
				// HACK: before this commit, versions were created with the current timestamp instead of the version's mtime.
				// This means that the name of some versions is the exact mtime of the next version. This behavior is now fixed.
				// To prevent occasional conflicts between the last version and the current one, we decrement the last version mtime.
				$mtime = (int)$version->getName();
				if ($mtime === $file->getMTime()) {
					$versionEntity->setTimestamp($mtime - 1);
					$version->move($version->getParent()->getPath() . '/' . ($mtime - 1));
				} else {
					$versionEntity->setTimestamp($mtime);
				}

				$versionEntity->setSize($version->getSize());
				// Use the main file mimetype for this initialization as the original mimetype is unknown.
				$versionEntity->setMimetype($this->mimeTypeLoader->getId($file->getMimetype()));
				$versionEntity->setDecodedMetadata([]);
				$this->groupVersionsMapper->insert($versionEntity);
			}

			return $this->getVersionsForFileFromDB($file, $user);
		} catch (NotFoundException) {
			return [];
		}
	}

	/**
	 * @return GroupVersion[]
	 */
	private function getVersionsForFileFromDB(FileInfo $fileInfo, IUser $user): array {
		$folder = $this->getFolderForFile($fileInfo);
		$mountPoint = $fileInfo->getMountPoint();
		if (!$fileInfo->getStorage()->instanceOfStorage(GroupFolderStorage::class)) {
			return [];
		}
		$versionsFolder = $this->getVersionFolderForFile($fileInfo);

		$fileInfoId = $fileInfo->getId();
		if ($fileInfoId === null) {
			throw new RuntimeException('Failed to get id of fileinfo.');
		}

		$versionEntities = $this->groupVersionsMapper->findAllVersionsForFileId($fileInfoId);
		$mappedVersions = array_map(
			function (GroupVersionEntity $versionEntity) use ($versionsFolder, $mountPoint, $fileInfo, $user, $folder): ?GroupVersion {
				$currentVersion = false;
				if ($fileInfo->getMtime() === $versionEntity->getTimestamp()) {
					$currentVersion = true;
					if ($fileInfo instanceof File) {
						$versionFile = $fileInfo;
					} else {
						$versionFile = $this->rootFolder->get($fileInfo->getPath());
					}
				} else {
					try {
						$versionFile = $versionsFolder->get((string)$versionEntity->getTimestamp());
					} catch (NotFoundException) {
						// The version does not exists on disk anymore, so we can delete its entity in the DB.
						// The reality is that the disk version might have been lost during a move operation between storages,
						// and its not possible to recover it, so removing the entity makes sense.
						$this->groupVersionsMapper->delete($versionEntity);

						return null;
					}
				}

				if (!$versionFile instanceof File) {
					$this->logger->warning('Encountered version file that was not a file', ['fileid' => $versionFile->getId(), 'path' => $versionFile->getPath()]);

					$versionFile->delete();
					$this->groupVersionsMapper->delete($versionEntity);

					return null;
				}

				return new GroupVersion(
					$versionEntity->getTimestamp(),
					$versionEntity->getTimestamp(),
					$fileInfo->getName(),
					$versionEntity->getSize(),
					$this->mimeTypeLoader->getMimetypeById($versionEntity->getMimetype()) ?? '',
					$mountPoint->getInternalPath($fileInfo->getPath()),
					$fileInfo,
					$this,
					$user,
					$versionEntity->getDecodedMetadata(),
					$versionFile,
					$folder,
					$currentVersion,
				);
			},
			$versionEntities,
		);

		// Filter out null values.
		return array_filter($mappedVersions);
	}

	public function createVersion(IUser $user, FileInfo $file): void {
		$versionsFolder = $this->getVersionFolderForFile($file);

		$versionMount = $versionsFolder->getMountPoint();
		$sourceMount = $file->getMountPoint();
		$sourceStorage = $sourceMount->getStorage();
		if ($sourceStorage === null) {
			throw new \RuntimeException('Failed to get storage for source mount.');
		}
		$sourceCache = $sourceStorage->getCache();
		$revision = $file->getMtime();

		$versionInternalPath = $versionsFolder->getInternalPath() . '/' . $revision;
		$sourceInternalPath = $file->getInternalPath();

		$sourceCacheEntry = $sourceCache->get($sourceInternalPath);
		if ($sourceCacheEntry === false) {
			throw new RuntimeException('Failed to get source cache entry');
		}

		$versionStorage = $versionMount->getStorage();
		if ($versionStorage === null) {
			throw new \RuntimeException('Failed to get storage for version mount.');
		}
		$versionStorage->copyFromStorage($sourceStorage, $sourceInternalPath, $versionInternalPath);
		$versionStorage->getCache()->copyFromCache($sourceCache, $sourceCacheEntry, $versionInternalPath);
	}

	public function rollback(IVersion $version): void {
		if (!($version instanceof GroupVersion)) {
			throw new \LogicException('Trying to restore a version from a file not in a Team folder');
		}

		if (!$this->currentUserHasPermissions($version->getSourceFile(), \OCP\Constants::PERMISSION_UPDATE)) {
			throw new Forbidden('You cannot restore this version because you do not have update permissions on the source file.');
		}

		$this->createVersion($version->getUser(), $version->getSourceFile());

		/** @var GroupMountPoint $targetMount */
		$targetMount = $version->getSourceFile()->getMountPoint();
		$targetStorage = $targetMount->getStorage();
		if ($targetStorage === null) {
			throw new \RuntimeException('Failed to get storage for target mount.');
		}
		$targetCache = $targetStorage->getCache();
		$versionMount = $version->getVersionFile()->getMountPoint();
		$versionStorage = $versionMount->getStorage();
		if ($versionStorage === null) {
			throw new \RuntimeException('Failed to get storage for version mount.');
		}
		$versionCache = $versionStorage->getCache();

		$targetInternalPath = $version->getSourceFile()->getInternalPath();
		$versionInternalPath = $version->getVersionFile()->getInternalPath();

		$versionCacheEntry = $versionCache->get($versionInternalPath);
		if ($versionCacheEntry === false) {
			throw new RuntimeException('Failed to get version cache entry');
		}

		$targetStorage->copyFromStorage($versionStorage, $versionInternalPath, $targetInternalPath);
		$targetCache->copyFromCache($versionCache, $versionCacheEntry, $targetInternalPath);
	}

	public function read(IVersion $version) {
		if ($version instanceof GroupVersion) {
			return $version->getVersionFile()->fopen('r');
		}

		return false;
	}

	public function getVersionFile(IUser $user, FileInfo $sourceFile, $revision): File {
		$versionsFolder = $this->getVersionFolderForFile($sourceFile);
		$file = $versionsFolder->get((string)$revision);
		assert($file instanceof File);

		return $file;
	}

	/**
	 * @param FolderWithMappingsAndCache $folder
	 * @return array<int, ?FileInfo>
	 */
	public function getAllVersionedFiles(FolderDefinitionWithMappings $folder): array {
		$versionsFolder = $this->getVersionsFolder($folder);
		$folderWithPermissions = FolderDefinitionWithPermissions::fromFolder($folder, $folder->rootCacheEntry, Constants::PERMISSION_ALL);
		$mount = $this->mountProvider->getMount($folderWithPermissions, '/groupfolders/' . $folder->mountPoint);
		$this->mountManager->addMount($mount);

		try {
			$contents = $versionsFolder->getDirectoryListing();
		} catch (NotFoundException) {
			return [];
		}

		$fileIds = array_map(fn (Node $node): int => (int)$node->getName(), $contents);
		$files = array_map(function (int $fileId) use ($mount): ?FileInfo {
			/** @var ?Storage $storage */
			$storage = $mount->getStorage();
			if ($storage === null) {
				throw new \RuntimeException('Failed to get storage for mount.');
			}

			$cacheEntry = $storage->getCache()->get($fileId);
			if ($cacheEntry) {
				return new \OC\Files\FileInfo($mount->getMountPoint() . '/' . $cacheEntry->getPath(), $storage, $cacheEntry->getPath(), $cacheEntry, $mount);
			} else {
				return null;
			}
		}, $fileIds);

		return array_combine($fileIds, $files);
	}

	public function deleteAllVersionsForFile(FolderDefinition $folder, int $fileId): void {
		$versionsFolder = $this->getVersionsFolder($folder);
		try {
			$versionsFolder->get((string)$fileId)->delete();
			$this->groupVersionsMapper->deleteAllVersionsForFileId($fileId);
		} catch (NotFoundException) {
		}
	}

	public function getVersionsFolder(FolderDefinition $folder): Folder {
		$mountPoint = '/dummy/files_versions/groupfolders/' . $folder->id;
		$mount = $this->mountManager->find($mountPoint);
		if ($mount === null) {
			throw new \RuntimeException('Failed to get mount for mountpoint.');
		}

		// check that $mount is the version mount, and not a mount for a parent folder
		if ($mount->getMountPoint() !== $mountPoint) {
			$versionMount = $this->mountProvider->getVersionsMount(
				$folder,
				$mountPoint,
				$this->storageFactory,
			);
			$this->mountManager->addMount($versionMount);
		}

		$folder = $this->rootFolder->get($mountPoint);
		if (!$folder instanceof Folder) {
			throw new RuntimeException('Versions folder was not a folder.');
		}

		return $folder;
	}

	public function setMetadataValue(Node $node, int $revision, string $key, string $value): void {
		if (!$this->currentUserHasPermissions($node, \OCP\Constants::PERMISSION_UPDATE)) {
			throw new Forbidden('You cannot update the version\'s metadata because you do not have update permissions on the source file.');
		}

		$versionEntity = $this->groupVersionsMapper->findVersionForFileId($node->getId(), $revision);

		$versionEntity->setMetadataValue($key, $value);
		$this->groupVersionsMapper->update($versionEntity);
	}

	public function deleteVersion(IVersion $version): void {
		if (!$this->currentUserHasPermissions($version->getSourceFile(), \OCP\Constants::PERMISSION_DELETE)) {
			throw new Forbidden('You cannot delete this version because you do not have delete permissions on the source file.');
		}

		$sourceFile = $version->getSourceFile();

		if (!$sourceFile->getStorage()->instanceOfStorage(GroupFolderStorage::class)) {
			return;
		}

		$folder = $this->getFolderForFile($sourceFile);
		$versionsFolder = $this->getVersionsFolder($folder)->get((string)$sourceFile->getId());
		/** @var Folder $versionsFolder */
		$versionsFolder->get((string)$version->getRevisionId())->delete();

		$versionFileId = $version->getSourceFile()->getId();
		if ($versionFileId === null) {
			throw new RuntimeException('Failed to get id of file.');
		}

		$versionEntity = $this->groupVersionsMapper->findVersionForFileId(
			$versionFileId,
			$version->getTimestamp(),
		);
		$this->groupVersionsMapper->delete($versionEntity);
	}

	public function createVersionEntity(File $file): null {
		$fileId = $file->getId();
		$timestamp = $file->getMTime();

		try {
			$this->groupVersionsMapper->findVersionForFileId($fileId, $timestamp);
		} catch (DoesNotExistException) {
			$versionEntity = new GroupVersionEntity();
			$versionEntity->setFileId($fileId);
			$versionEntity->setTimestamp($timestamp);
			$versionEntity->setSize($file->getSize());
			$versionEntity->setMimetype($this->mimeTypeLoader->getId($file->getMimetype()));
			$versionEntity->setDecodedMetadata([]);
			$this->groupVersionsMapper->insert($versionEntity);
		}

		return null;
	}

	/**
	 * @param array{timestamp?: int, size?: int, mimetype?: int} $properties
	 */
	public function updateVersionEntity(File $sourceFile, int $revision, array $properties): void {
		$versionEntity = $this->groupVersionsMapper->findVersionForFileId($sourceFile->getId(), $revision);

		if (isset($properties['timestamp'])) {
			$versionEntity->setTimestamp($properties['timestamp']);
		}

		if (isset($properties['size'])) {
			$versionEntity->setSize($properties['size']);
		}

		if (isset($properties['mimetype'])) {
			$versionEntity->setMimetype($properties['mimetype']);
		}

		$this->groupVersionsMapper->update($versionEntity);
	}

	public function deleteVersionsEntity(File $file): void {
		$this->groupVersionsMapper->deleteAllVersionsForFileId($file->getId());
	}

	private function currentUserHasPermissions(FileInfo $sourceFile, int $permissions): bool {
		$currentUserId = $this->userSession->getUser()?->getUID();

		if ($currentUserId === null) {
			throw new NotFoundException('No user logged in');
		}

		return ($sourceFile->getPermissions() & $permissions) === $permissions;
	}

	public function importVersionsForFile(IUser $user, Node $source, Node $target, array $versions): void {
		if (!$target->getStorage()->instanceOfStorage(GroupFolderStorage::class)) {
			return;
		}

		$versionsFolder = $this->getVersionFolderForFile($target);

		foreach ($versions as $version) {
			// 1. Move the file to the new location
			if ($version->getTimestamp() !== $source->getMTime()) {
				$backend = $version->getBackend();
				$versionFile = $backend->getVersionFile($user, $source, $version->getRevisionId());
				$versionFileHandle = $versionFile->fopen('r');
				if ($versionFileHandle === false) {
					throw new RuntimeException('Failed to open version file.');
				}
				$versionsFolder->newFile((string)$version->getRevisionId(), $versionFileHandle);
			}

			// 2. Create the entity in the database
			$versionEntity = new GroupVersionEntity();
			$versionEntity->setFileId($target->getId());
			$versionEntity->setTimestamp($version->getTimestamp());
			$versionEntity->setSize($version->getSize());
			$versionEntity->setMimetype($this->mimeTypeLoader->getId($version->getMimetype()));
			if ($version instanceof IMetadataVersion) {
				$versionEntity->setDecodedMetadata($version->getMetadata());
			}

			try {
				$this->groupVersionsMapper->insert($versionEntity);
			} catch (\OCP\DB\Exception $e) {
				if ($e->getReason() !== \OCP\DB\Exception::REASON_UNIQUE_CONSTRAINT_VIOLATION) {
					throw $e;
				}
			}
		}
	}

	public function moveVersionsBetweenFolders(Node $node, FolderDefinition $sourceFolder, FolderDefinition $targetFolder): void {
		$sourceVersionsFolder = $this->getVersionsFolder($sourceFolder);
		$targetVersionsFolder = $this->getVersionsFolder($targetFolder);
		$this->moveVersionsBetweenFoldersInner($node, $sourceVersionsFolder, $targetVersionsFolder);
	}

	private function moveVersionsBetweenFoldersInner(Node $node, Folder $sourceVersionsFolder, Folder $targetVersionsFolder): void {
		if ($node instanceof Folder) {
			foreach ($node->getDirectoryListing() as $child) {
				$this->moveVersionsBetweenFoldersInner($child, $sourceVersionsFolder, $targetVersionsFolder);
			}
		} else {
			try {
				$versionsDir = $sourceVersionsFolder->get((string)$node->getId());
				$versionsDir->move($targetVersionsFolder->getFullPath((string)$node->getId()));
			} catch (NotFoundException|NotPermittedException) {
				// continue
			}
		}
	}

	/**
	 * @inheritdoc
	 */
	public function clearVersionsForFile(IUser $user, Node $source, Node $target): void {
		$folder = $this->getFolderForFile($source);
		$this->deleteAllVersionsForFile($folder, $target->getId());
	}

	public function getRevision(\OC\Files\Node\Node $node): int {
		return $node->getMTime();
	}
}
