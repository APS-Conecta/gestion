<!--
@license GNU AGPL version 3 or any later version

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
-->
<template>
  <h2>{{ t('side_menu', label) }}</h2>
</template>

<script setup>
const { label } = defineProps({
  label: {
    type: String,
    required: true,
  },
})
</script>

<style scoped>
h2 {
  font-size: 1.3em;
  margin: 0 0 12px 0;
}
</style>
