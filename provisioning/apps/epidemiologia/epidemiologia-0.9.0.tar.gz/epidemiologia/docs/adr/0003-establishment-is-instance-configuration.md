# ADR-0003 — the establishment is instance configuration, never a constant (moved)

- **Status:** moved 2026-08-09 to
  [`gestion/docs/adr/0013-the-establishment-is-instance-configuration.md`](https://github.com/APS-Conecta/gestion/blob/main/docs/adr/0013-the-establishment-is-instance-configuration.md),
  which is now the only copy. Still **accepted**; nothing about the decision changed.

It binds every app, not just this one, and its body is about `gestion`'s files — so it does not
belong in a leaf repository three of the four apps cannot see. See
[gestion ADR-0011](https://github.com/APS-Conecta/gestion/blob/main/docs/adr/0011-org-wide-facts-live-in-gestion.md).
This stub stays so that anything already pointing here still arrives, and so that the number is
never reused.
