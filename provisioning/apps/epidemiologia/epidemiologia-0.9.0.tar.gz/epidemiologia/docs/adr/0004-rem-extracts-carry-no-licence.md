# The DEIS REM extracts carry no licence, and we record that rather than assume one

**Status: accepted, 2026-08-02.** Still standing, but not to act on here: this app never fetches
REM.
`https://repositoriodeis.minsal.cl/DatosAbiertos/REM/SERIE_REM_<year>.zip` states **no licence and
no reuse terms**, so its catalogue entry says `license: unknown` — not `open`, not `cc0`: either would
assert a fact the source does not state.
