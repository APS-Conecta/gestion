<?php

declare(strict_types=1);

/**
 * Mount point. Everything the page shows comes from src/, and its data arrives
 * through IInitialState rather than through $_ — see PageController::index().
 */
?>
<div id="epidemiologia"></div>
