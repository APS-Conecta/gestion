# Epidemiología

Nextcloud 34 app for APS Conecta Gestión. It surfaces the epidemiological information MINSAL
publishes inside the intranet, and links to what cannot be surfaced.

Five views:

| View | What it is | Where it comes from |
| --- | --- | --- |
| **Inicio** | What was published most recently, freshness first | Everything below, already loaded |
| **Alertas vigentes** | The oficios in force, filterable by text and by year | Public REST API on `epi.minsal.cl` |
| **Informe semanal** | The ETI/IRAG report for the current semana epidemiológica | Public REST API on `epi.minsal.cl` |
| **Alertas sanitarias ISP** | Recalls, falsifications, pharmacovigilance, device withdrawals | 24 hourly RSS feeds on `ispch.gob.cl` |
| **Tablero MINSAL** | The national dashboard, embedded | Power BI *"Publish to web"* |
| **EPIVIGILA** | What it is, how to get in, and the real access situation | A link, never embedded |

It only reads and links public information. **It does not copy or rehost state documents, it creates
no database tables, and it touches no patient data.**

The UI is in Spanish because clinicians read it. Everything else here — code, comments, docs, this
file — is in English; see [`AGENTS.md`](AGENTS.md).

## How it works

A read-through proxy with a cache, and no database:

- Pages are resolved **by slug, never by ID** — IDs change when MINSAL republishes.
- PDFs are **read from the anchors, never constructed**: the upload folder is not derivable from the
  semana epidemiológica (SE 29 sits under `2026/07`, SE 24 under `2026/06`).
- The cache refreshes hourly, but **a read that returns zero items is a failure, never a result**:
  the cache is not overwritten, the last good copy keeps being served behind a *problemas técnicos*
  banner, and whoever administers the instance is told. Without that rule, a change to MINSAL's page
  would replace 75 real alerts with an empty list that a clinician reads as "no hay alertas
  vigentes".
- **The ISP's rule is deliberately different**: one empty feed is normal, and only failing to reach
  any of the 24 is degradation. That disagreement is why `IspRepository` is a sibling of
  `MinsalRepository` rather than a second source inside it.
- A daily job at 03:00 asks only for the modification date (**859 bytes** against 44 KB) to
  **detect** that MINSAL changed. It exists to detect, not to warm the cache.

## For other apps

**One** read-only OCS route, with every source keyed by its id. **The `OCS-APIRequest` header is not
optional**: without it Nextcloud answers `412` before reaching the controller.

```
GET /ocs/v2.php/apps/epidemiologia/api/v1/sources?format=json
OCS-APIRequest: true

{ "ocs": { "meta": { "status": "ok", "statuscode": 200 },
           "data": {
             "alerts": { "updated_at": "2026-07-31T22:15:04",
                         "degraded": false,
                         "items": [ { "title": "OFICIO CP N°15844 / 2026 …",
                                      "url": "https://…pdf", "year": "2026" } ] },
             "reports":         { "…": "…" },
             "sanitary_alerts": { "…": "…" } } } }
```

The data sits inside `ocs.data`. With `format=xml` you get the same thing in XML, for free. **Each
source carries its own freshness and its own `degraded`**, so an ISP outage does not make MINSAL look
stale. Alerts also carry `month`; reports carry `se` (semana epidemiológica); sanitary alerts carry
`date` and `categories`.

**One route rather than one per source**, because that is how Nextcloud serves this kind of consumer
— `dashboard` returns `ocs.data` keyed by widget, `cloud/capabilities` keyed by app — and because
adding a source now adds a key rather than a route. See
[`docs/adr/0006`](docs/adr/0006-one-ocs-route-keyed-by-source.md).

The tablero is not in there: it is a constant URL, with nothing to fetch, parse, cache or degrade.

**The contract lives in [`openapi.json`](openapi.json)**, generated from the controller's attributes
and docblocks with `scripts/openapi.sh` — never by hand, because a hand-written spec drifts from the
code silently, which is worse than having none.

Reading through here beats reading MINSAL directly: a shared cache, an already-parsed format, and the
`degraded` flag.

### Why OCS and not a plain route

The manual calls `OCSController` the current approach, but the concrete reason is the web page /
information centre that is coming: **a browser on another origin cannot be served any other way**.
Enabling CORS on a plain `Controller` is *"generally and highly discouraged"* — the CSRF check then
fails unless security is disabled.

There is still **no `#[CORS]`**: it needs a concrete origin and the dashboard does not have one.
Adding it blind would widen the surface for nobody. There is a rate limit: 120 requests per minute
per user, a ceiling against a runaway consumer rather than a quota.

> The previous routes **no longer exist**. They are not deprecated, they are gone:
> `/apps/epidemiologia/api/v1/…` in 0.2.0, and `/ocs/…/api/v1/alerts` and `…/reports` in 0.3.0.
> Nobody was consuming them, and keeping two contracts would have cost more than breaking an empty
> one.

## Development

```sh
scripts/test.sh     # unit suite, inside the container (PHPUnit 11)
scripts/smoke.sh    # checks the wiring against the running instance
scripts/openapi.sh  # regenerates openapi.json from the controller
```

`scripts/test.sh` covers the only things with real logic: parsing, ordering, the year, the semana
epidemiológica, degradation, accent folding, and the catalogue of sources. The fixtures are **real
captured responses** from MINSAL and the ISP, not invented markup — so the parsers are proven against
what those sites actually publish, quirks included.

`scripts/smoke.sh` checks what no unit test can see: that the app enables, that the daily job is
registered, that the OCS route answers **with its envelope** and refuses with `412` without the
header, that every source appears in the payload, that the old routes 404, that the icon is served,
that **the `js/` bundle matches `src/`**, and that **the CSP allows the tablero's domain**. That last
one is a single line in a controller; without it the tablero renders blank, and it looks like MINSAL
is down rather than like we broke it.

### Things that bite

- **`occ app:enable` on an already-enabled app does not register the background job.** If `smoke.sh`
  reports it missing, run `occ app:disable` and then `occ app:enable`.
- **Raising `<version>` in `info.xml` puts the whole instance into "requires upgrade".** `occ` drops
  into limited mode and the web routes stop answering until `occ upgrade` runs. A `git pull` that
  brings a version change needs that step behind it.
- **After `npm run build`, a browser that already visited the app loses its styles.** The entry file
  `css/epidemiologia-main.css` only `@import`s the chunk, and the chunk carries a **content hash**
  that changes on every build. But the entry's URL carries `?v=<cachebuster>`, which does **not**
  change unless the app version does — so the browser serves a cached entry importing a chunk the
  build already deleted, and the app appears unstyled. Measured; it costs three reloads to work out.
  It fixes itself on release (raising `<version>` moves the cachebuster); in development, force-reload
  the `.css` as well as the `.mjs`.
- **`opcache.revalidate_freq` is 60 s**, so a PHP change can take a minute to show up.
- **Adding or changing attribute routes needs a container restart.** `CachingRouter` keeps the
  compiled route collection for **an hour** in the *local* cache (APCu), and APCu is per-SAPI:
  clearing it from `occ` does nothing, because the CLI and the web do not share it. The symptom is
  `998 Invalid query` from OCS while `occ` lists the route quite happily.
- **Do not pipe `docker exec … | grep -q`**: `grep` closes the pipe on its first match, the writer
  dies of SIGPIPE, and under `pipefail` a passing check reports as a failure.

## Installation

The directory goes in `gestion/apps/` (mounted at `custom_apps`) and is enabled with
`occ app:enable epidemiologia`. **There are no migrations to run**: the app creates no tables.

`js/` and `css/` **are committed**, so deploying stays a `git pull` and needs no Node on the server.
Anyone touching `src/` does have to run `npm run build` and commit the result — `scripts/smoke.sh`
reports it if the bundle falls behind.

> **`node_modules` should not live in the webroot of a production instance.** The app's `.htaccess`
> closes it off, but that depends on Apache and on `AllowOverride`; Nextcloud's own `.htaccess`
> whitelists the `js` and `mjs` extensions, so without that protection the ~300 MB of dependencies
> are served to any authenticated user. The right fix is to build elsewhere and deploy only what is
> needed.

## Licence

AGPL-3.0-or-later. Data source: Departamento de Epidemiología, MINSAL, and Instituto de Salud
Pública de Chile.
