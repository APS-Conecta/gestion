# The DEIS REM extracts carry no licence, and we record that rather than assume one

**Accepted, and moved:** this app never fetches REM; [ADR-0001](0001-analizador-rem-owns-rem.md) owns
it. `https://repositoriodeis.minsal.cl/DatosAbiertos/REM/SERIE_REM_<year>.zip` states **no licence and
no reuse terms**, so its catalogue entry says `license: unknown` — not `open`, not `cc0`: either would
assert a fact the source does not state.
