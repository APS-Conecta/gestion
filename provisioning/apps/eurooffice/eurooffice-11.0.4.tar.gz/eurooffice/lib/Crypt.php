<?php
/**
 *
 * (c) Copyright Ascensio System SIA 2026
 *
 * This program is a free software product.
 * You can redistribute it and/or modify it under the terms of the GNU Affero General Public License
 * (AGPL) version 3 as published by the Free Software Foundation.
 * In accordance with Section 7(a) of the GNU AGPL its Section 15 shall be amended to the effect
 * that Ascensio System SIA expressly excludes the warranty of non-infringement of any third-party rights.
 *
 * This program is distributed WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * For details, see the GNU AGPL at: http://www.gnu.org/licenses/agpl-3.0.html
 *
 * The interactive user interfaces in modified source and object code versions of the Program
 * must display Appropriate Legal Notices, as required under Section 5 of the GNU AGPL version 3.
 *
 *
 * All the Product's GUI elements, including illustrations and icon sets, as well as technical
 * writing content are licensed under the terms of the Creative Commons Attribution-ShareAlike 4.0 International.
 * See the License terms at http://creativecommons.org/licenses/by-sa/4.0/legalcode
 *
 */

namespace OCA\Eurooffice;

use DomainException;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use UnexpectedValueException;

/**
 * Token generator
 *
 * @package OCA\Eurooffice
 */
class Crypt {

    public function __construct(private readonly AppConfig $appConfig) {}

    /**
     * Generate token for the object
     *
     * @param array $object - object to signature
     */
    public function getHash(array $object): string {
        try {
            return JWT::encode($object, $this->appConfig->getSKey(), "HS256");
        } catch (DomainException $e) {
            throw new \RuntimeException("JWT secret key is too short (minimum 32 characters required). Please update the Secret Key in Nextcloud Office settings.", 0, $e);
        }
    }

    /**
     * Create an object from the token
     *
     * @param string $token - token
     */
    public function readHash(string $token): array {
        $result = null;
        $error = null;
        if ($token === "") {
            return [$result, "token is empty"];
        }
        try {
            $result = JWT::decode($token, new Key($this->appConfig->getSKey(), "HS256"));
        } catch (DomainException | UnexpectedValueException $e) {
            $error = $e->getMessage();
        }
        return [$result, $error];
    }
}
