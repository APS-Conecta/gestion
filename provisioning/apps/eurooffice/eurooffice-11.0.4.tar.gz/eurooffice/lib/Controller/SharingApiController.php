<?php
/**
 *
 * (c) Copyright Ascensio System SIA 2026
 *
 * This program is a free software product.
 * You can redistribute it and/or modify it under the terms of the GNU Affero General Public License
 * (AGPL) version 3 as published by the Free Software Foundation.
 * In accordance with Section 7(a) of the GNU AGPL its Section 15 shall be amended to the effect
 * that Ascensio System SIA expressly excludes the warranty of non-infringement of any third-party rights.
 *
 * This program is distributed WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * For details, see the GNU AGPL at: http://www.gnu.org/licenses/agpl-3.0.html
 *
 * The interactive user interfaces in modified source and object code versions of the Program
 * must display Appropriate Legal Notices, as required under Section 5 of the GNU AGPL version 3.
 *
 *
 * All the Product's GUI elements, including illustrations and icon sets, as well as technical
 * writing content are licensed under the terms of the Creative Commons Attribution-ShareAlike 4.0 International.
 * See the License terms at http://creativecommons.org/licenses/by-sa/4.0/legalcode
 *
 */

namespace OCA\Eurooffice\Controller;

use OCA\Files_Sharing\SharedStorage;
use OCA\Eurooffice\AppConfig;
use OCA\Eurooffice\ExtraPermissions;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\OCSController;
use OCP\Files\File;
use OCP\Files\IRootFolder;
use OCP\IRequest;
use OCP\IUserSession;
use OCP\Share\IManager;
use OCP\Share\IShare;
use Psr\Log\LoggerInterface;

/**
 * OCS handler
 */
class SharingApiController extends OCSController {

    public function __construct(
        string $appName,
        IRequest $request,
        private readonly IRootFolder $root,
        private readonly LoggerInterface $logger,
        private readonly IUserSession $userSession,
        private readonly IManager $shareManager,
        private readonly AppConfig $appConfig,
        private readonly ExtraPermissions $extraPermissions
    ) {
        parent::__construct($appName, $request);
    }

    /**
     * Get shares for file
     *
     * @param integer $fileId - file identifier
     *
     * @return DataResponse
     */
    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function getShares(int $fileId): DataResponse {
        if (!$this->appConfig->getAdvanced()) {
            $this->logger->debug("extraPermissions isn't init");
            return new DataResponse([], Http::STATUS_BAD_REQUEST);
        }

        $user = $this->userSession->getUser();
        $userId = $user->getUID();

        $sourceFile = $this->getFile($fileId, $userId);
        $fileStorage = $sourceFile->getStorage();
        if ($fileStorage->instanceOfStorage(SharedStorage::class)) {
            return new DataResponse([]);
        }

        $sharesUser = $this->shareManager->getSharesBy($userId, IShare::TYPE_USER, $sourceFile, true);
        $sharesGroup = $this->shareManager->getSharesBy($userId, IShare::TYPE_GROUP, $sourceFile, true);
        $sharesRoom = $this->shareManager->getSharesBy($userId, IShare::TYPE_ROOM, $sourceFile, true);
        $sharesLink = $this->shareManager->getSharesBy($userId, IShare::TYPE_LINK, $sourceFile, true);
        $shares = array_merge($sharesUser, $sharesGroup, $sharesRoom, $sharesLink);
        $extras = $this->extraPermissions->getExtras($shares);

        return new DataResponse($extras);
    }

    /**
     * Set shares for file
     *
     * @param integer $extraId - extra permission identifier
     * @param string $shareId - share identifier
     * @param integer $fileId - file identifier
     * @param integer $permissions - permissions bitmask
     *
     * @return DataResponse
     */
    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function setShares(int $extraId, string $shareId, int $fileId, int $permissions): DataResponse {
        if (!$this->appConfig->getAdvanced()) {
            $this->logger->debug("extraPermissions isn't init");
            return new DataResponse([], Http::STATUS_BAD_REQUEST);
        }

        $user = $this->userSession->getUser();
        $userId = $user->getUID();

        $sourceFile = $this->getFile($fileId, $userId);
        $fileStorage = $sourceFile->getStorage();
        if ($fileStorage->instanceOfStorage(SharedStorage::class)) {
            return new DataResponse([], Http::STATUS_BAD_REQUEST);
        }

        if (!$this->extraPermissions->setExtra($shareId, $permissions, $extraId)) {
            $this->logger->error("setShares: couldn't set extra permissions for: " . $shareId);
            return new DataResponse([], Http::STATUS_BAD_REQUEST);
        }

        $extra = $this->extraPermissions->getExtra($shareId);

        return new DataResponse($extra);
    }

    /**
     * Get source file
     *
     * @param integer $fileId - file identifier
     * @param string $userId - user identifier
     *
     * @return File
     */
    private function getFile(int $fileId, string $userId): ?File {
        try {
            $folder = $this->root->getUserFolder($userId);
            $files = $folder->getById($fileId);
        } catch (\Exception $e) {
            $this->logger->error("getFile: $fileId", ["exception" => $e]);
            return null;
        }

        if (empty($files)) {
            $this->logger->error("getFile: file not found: " . $fileId);
            return null;
        }

        return $files[0];
    }
}
