const o=`<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg xmlns="http://www.w3.org/2000/svg" height="32" width="32" version="1.0" viewBox="0 0 32 32">
 <path style="color:#000000;block-progression:tb;text-transform:none;text-indent:0" fill="#000" d="m4.6992 2.004c-0.395 0.0764-0.7062 0.4666-0.6992 0.875v26.244c0 0.46 0.4122 0.876 0.8632 0.876h22.276c0.452 0 0.864-0.416 0.864-0.876v-20.284c-0.008-0.1338-0.046-0.266-0.11-0.383l-6.624-6.3984c-0.086-0.0328-0.178-0.051-0.27-0.0546h-16.137c-0.0532-0.0053-0.11-0.0053-0.1636 0zm3.3008 3.996h12v2h-12v-2zm0 6h10v2h-10v-2zm0 6h16v2h-16v-2zm0 6h8v2h-8v-2z"/>
</svg>
`;export{o as A};
//# sourceMappingURL=app-dark-zOuC8avK.chunk.mjs.map
