const n=(c,t)=>{const o=c.__vccOpts||c;for(const[r,s]of t)o[r]=s;return o};export{n as _};
//# sourceMappingURL=_plugin-vue_export-helper-BVe3zTfJ.chunk.mjs.map
