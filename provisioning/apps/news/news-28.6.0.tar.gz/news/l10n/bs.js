OC.L10N.register(
    "news",
    {
    "Download" : "Preuzmite",
    "Close" : "Zatvori",
    "Username" : "Korisničko ime",
    "Password" : "Lozinka",
    "New folder" : "Nova fascikla",
    "Credentials" : "Vjerodajnice",
    "Move" : "Move",
    "Share" : "Podjeli",
    "Starred" : "Označeno",
    "Rename" : "Preimenuj",
    "Delete" : "Obriši",
    "from" : "od",
    "by" : "od strane",
    "Import" : "Uvezi",
    "Export" : "Izvezi",
    "Keyboard shortcuts" : "Tipkovni prečaci",
    "Title" : "Naslov",
    "Folder" : "Fasikla",
    "Save" : "Spremi"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
