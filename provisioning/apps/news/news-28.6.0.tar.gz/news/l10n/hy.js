OC.L10N.register(
    "news",
    {
    "Download" : "Բեռնել",
    "Close" : "Փակել",
    "Folder name" : "Պանակի անուն",
    "Username" : "Օգտանուն",
    "Password" : "Գաղտնաբառ",
    "New folder" : "Նոր պանակ",
    "Credentials" : "Credentials",
    "Move" : "Տեղափոխել",
    "Share" : "Կիսվել",
    "Rename" : "Վերանվանել",
    "Delete" : "հեռացնել",
    "Never" : "Երբեք",
    "General" : "Ընդհանուր",
    "Import" : "Ներմուծում",
    "Export" : "Արտահանում",
    "Refresh" : "Թարմացնել",
    "Folder" : "Պանակ",
    "Save" : "Պահպանել"
},
"nplurals=2; plural=(n != 1);");
