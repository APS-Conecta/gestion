OC.L10N.register(
    "news",
    {
    "News" : "පුවත්",
    "Someone" : "යමෙක්",
    "Download" : "බාගන්න",
    "Close" : "වසන්න",
    "Web address" : "වියමන ලිපිනය",
    "Folder name" : "බහාලුමේ නම",
    "Username" : "පරිශීලක නාමය",
    "Password" : "මුර පදය",
    "New folder" : "නව බහාලුම",
    "Folder exists already!" : "බහාලුම දැනටමත් පවතී!",
    "Update interval" : "යාවත්කාලීන කාල පරතරය",
    "Share" : "බෙදාගන්න",
    "Rename" : "නැවත නම් කරන්න",
    "from" : "සිට",
    "Open website" : "වියමන අඩවිය විවෘත කරන්න",
    "General" : "සමාන්‍යය",
    "Folder" : "බහාලුම"
},
"nplurals=2; plural=(n != 1);");
