OC.L10N.register(
    "news",
    {
    "Download" : "Muat turun",
    "Close" : "Tutup",
    "Web address" : "Alamat sesawang",
    "Username" : "Nama pengguna",
    "Password" : "Kata laluan",
    "Credentials" : "Credentials",
    "Move" : "Move",
    "Share" : "Kongsi",
    "Rename" : "Namakan",
    "Delete" : "Padam",
    "from" : "dari",
    "by" : "oleh",
    "General" : "Umum",
    "Import" : "Import",
    "Export" : "Eksport",
    "Refresh" : "Refresh",
    "Folder" : "Folder",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
