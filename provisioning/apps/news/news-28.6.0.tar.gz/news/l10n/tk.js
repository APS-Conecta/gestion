OC.L10N.register(
    "news",
    {
    "%1$s shared \"%2$s\" with you" : "Siziň bilen %1$spaýlaşdy%2$s",
    "Download" : "12",
    "Close" : "Ýap",
    "Folder name" : "Papkanyň ady",
    "Username" : "Ulanyjy ady",
    "Password" : "Açarsöz",
    "New folder" : "Täze papka döretmek",
    "Move" : "Göçüriň",
    "Share" : "Paýlaş",
    "Rename" : "Adyny üýtgetmek",
    "Delete" : "Pozmak",
    "Newest first" : "Täze ilkinji",
    "Oldest first" : "Ilki bilen iň köne",
    "Default" : "Bellenen",
    "General" : "Esasy",
    "Media" : "Mediýa",
    "Refresh" : "Täzelemek",
    "Not available" : "Elýeterli däl",
    "Save" : "Saklamak"
},
"nplurals=2; plural=(n != 1);");
