<?php
declare(strict_types=1);
/** The SPA host: everything renders inside this one mount point. The fallback
 * line is replaced by the app on a clean boot and left standing when the
 * bundle never mounts (farmacia's shape).
 */
?>
<div id="estadistica">Si este mensaje no desaparece, la aplicación no pudo cargar: avise al administrador.</div>
