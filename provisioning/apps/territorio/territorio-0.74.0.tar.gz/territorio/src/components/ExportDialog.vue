<template>
	<NcDialog name="Exportar" size="normal" @closing="$emit('close')">
		<p class="territorio-export__count">
			Se exportarán <strong>{{ count }}</strong>
			{{ count === 1 ? 'registro' : 'registros' }}: lo que está viendo ahora,
			con las capas y la búsqueda aplicadas.
		</p>

		<fieldset class="territorio-export__formats">
			<legend>Formato</legend>
			<NcCheckboxRadioSwitch v-for="option in FORMATS"
				:key="option.value"
				:model-value="format"
				:value="option.value"
				name="territorio-export-format"
				type="radio"
				@update:model-value="format = $event">
				{{ option.label }}
			</NcCheckboxRadioSwitch>
		</fieldset>

		<!--
			Said before the export runs, not after — the point is that somebody
			expecting their phone numbers can still choose a different format. Same
			rule as the import dialog's KML notice, for the same reason.
		-->
		<NcNoteCard v-if="kmlFamily" type="warning">
			Un archivo {{ format.toUpperCase() }} lleva solamente el nombre y la
			ubicación. No lleva teléfono, correo, persona de contacto, cargo,
			dirección, horario, notas, fuente, categoría ni el límite de un sector.
			Para un archivo completo, use GeoJSON.
		</NcNoteCard>

		<NcCheckboxRadioSwitch v-if="!kmlFamily"
			:model-value="contacts"
			type="switch"
			@update:model-value="contacts = $event">
			Incluir datos de contacto
		</NcCheckboxRadioSwitch>

		<!--
			ADR-0006. The Registry holds the mobile numbers of identifiable people —
			presidentas and secretarios of juntas de vecinos — and this is where a
			coordination tool becomes a portable contact list. So the prompt is
			Nextcloud's own, it is asked for THIS export, and the export is recorded.
		-->
		<NcNoteCard v-if="contacts && !kmlFamily" type="info">
			Este archivo lleva nombres, teléfonos y correos de personas. Se le pedirá
			su contraseña y quedará registrado quién exportó, cuándo y cuántos
			registros.
		</NcNoteCard>

		<NcNoteCard v-if="error !== ''" type="error">{{ error }}</NcNoteCard>

		<template #actions>
			<NcButton :disabled="working" @click="$emit('close')">
				Cancelar
			</NcButton>
			<NcButton :disabled="working || count === 0" variant="primary" @click="send">
				{{ working ? 'Exportando…' : 'Exportar' }}
			</NcButton>
		</template>
	</NcDialog>
</template>

<script>
import axios from '@nextcloud/axios'
import { PwdConfirmationMode } from '@nextcloud/password-confirmation'
import { generateUrl } from '@nextcloud/router'
import NcButton from '@nextcloud/vue/components/NcButton'
import NcCheckboxRadioSwitch from '@nextcloud/vue/components/NcCheckboxRadioSwitch'
import NcDialog from '@nextcloud/vue/components/NcDialog'
import NcNoteCard from '@nextcloud/vue/components/NcNoteCard'

const FORMATS = [
	{ value: 'geojson', label: 'GeoJSON — completo, se puede volver a importar' },
	{ value: 'csv', label: 'CSV — para planilla de cálculo' },
	{ value: 'kml', label: 'KML — solo nombre y ubicación, para Google Earth' },
	{ value: 'kmz', label: 'KMZ — el KML comprimido, pesa menos' },
]

export default {
	name: 'ExportDialog',

	components: { NcButton, NcCheckboxRadioSwitch, NcDialog, NcNoteCard },

	props: {
		/** The ids on screen right now. The filter is personal and lives here. */
		ids: { type: Array, required: true },
		/**
		 * How the person had narrowed the screen, in their own words.
		 *
		 * ADR-0006 asks the log to record the SCOPE of an export. A count is its
		 * size: "42 registros" does not say whose. This is the sentence that says
		 * whose, and only this component knows it, because the filter is personal
		 * and never leaves the browser (CONTEXT.md).
		 */
		scope: { type: String, default: '' },
	},

	emits: ['close'],

	data() {
		return {
			FORMATS,
			format: 'geojson',
			// Off by default. An export that carries nobody's telephone number is
			// the one somebody should have to ask for on purpose.
			contacts: false,
			working: false,
			error: '',
		}
	},

	computed: {
		count() {
			return this.ids.length
		},

		/**
		 * A KMZ is a KML in a ZIP (#102), so everything that is true of a KML
		 * because of what the FORMAT can hold is true of both. Asked once here
		 * rather than compared against 'kml' at each of the four places that care:
		 * a fifth place, or a fourth format, is where those drift apart, and a
		 * dialog that offers the contacts switch for a file that cannot carry them
		 * asks for a password over nothing (ADR-0006).
		 */
		kmlFamily() {
			return this.format === 'kml' || this.format === 'kmz'
		},

		/**
		 * A KML carries no contact details whatever is asked for, so it never needs
		 * the confirmation and never goes to the confirmed route.
		 */
		carriesContacts() {
			return this.contacts && !this.kmlFamily
		},
	},

	methods: {
		async send() {
			this.working = true
			this.error = ''

			try {
				const { data, headers } = await axios.post(
					generateUrl(this.carriesContacts
						? '/apps/territorio/export/contacts'
						: '/apps/territorio/export'),
					{ ids: this.ids, format: this.format, scope: this.scope },
					{
						// Blob, not JSON: this response is a file, and letting axios
						// parse it would turn a CSV into a string with the encoding
						// guessed and a KML into nothing useful.
						responseType: 'blob',
						// Nextcloud's own prompt, never a password field of ours
						// (ADR-0006), and Strict because the route is strict: the
						// confirmation has to be part of THIS request rather than a
						// note in the session from twenty minutes ago. The
						// interceptor that reads this is installed in main.js.
						...(this.carriesContacts
							? { confirmPassword: PwdConfirmationMode.Strict }
							: {}),
					},
				)

				this.save(data, headers['content-disposition'])
				this.$emit('close')
			} catch (exception) {
				// Deciding not to type your password is not a failure, and saying
				// "no se pudo exportar" to somebody who just pressed Cancelar is
				// worse than saying nothing. The string is the one
				// @nextcloud/password-confirmation actually throws — it is not
				// exported as a constant, so this is checked against the installed
				// version and pinned by the test below it in tests/js.
				if (exception?.message !== 'Dialog closed') {
					this.error = await this.reasonFrom(exception)
				}
			} finally {
				this.working = false
			}
		},

		/**
		 * What the server said, out of a response we asked for as a Blob.
		 *
		 * `responseType: 'blob'` applies to the error body too, so
		 * `error.response.data.message` is always undefined and every Spanish
		 * message the controller writes would go unread — the caller would be
		 * told "inténtelo de nuevo" about a file that will never work.
		 */
		async reasonFrom(exception) {
			const body = exception.response?.data
			const fallback = 'No se pudo exportar. Inténtelo de nuevo.'

			try {
				return JSON.parse(await body.text()).message ?? fallback
			} catch {
				// Not JSON, not a Blob, or no response at all — a dropped
				// connection looks like this.
				return fallback
			}
		},

		/** Hand the file to the browser the only way a POST response can. */
		save(blob, disposition) {
			const url = URL.createObjectURL(blob)
			const link = document.createElement('a')
			link.href = url
			link.download = this.filenameFrom(disposition)
			document.body.appendChild(link)
			link.click()
			link.remove()
			// Revoked, or the whole file stays in memory until the tab closes, and
			// a comuna's catastro is not a small string. On a turn of the event
			// loop rather than immediately: Firefox aborts a download whose object
			// URL is revoked in the same tick as the click, and Chromium does not
			// — so the browser gate would never have found it.
			setTimeout(() => URL.revokeObjectURL(url), 0)
		},

		/** The server names the file; this is the fallback when it did not. */
		filenameFrom(disposition) {
			const match = /filename="?([^";]+)"?/.exec(disposition ?? '')

			return match?.[1] ?? `territorio.${this.format}`
		},
	},
}
</script>

<style scoped>
.territorio-export__count {
	margin-bottom: 12px;
}

.territorio-export__formats {
	border: 0;
	padding: 0;
	margin: 0 0 12px;
}

.territorio-export__formats legend {
	font-weight: bold;
	margin-bottom: 4px;
}
</style>
