import { createApp } from 'vue'
import AdminSettings from './AdminSettings.vue'

createApp(AdminSettings).mount('#territorio-admin')
