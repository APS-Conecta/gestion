<?php

declare(strict_types=1);

namespace OCA\Territorio\Tests\Unit\Service;

use OCA\Territorio\Exception\InvalidImportException;
use OCA\Territorio\Service\ContactFields;
use OCA\Territorio\Service\GeoJsonReader;
use OCA\Territorio\Service\GeoJsonWriter;
use PHPUnit\Framework\TestCase;

/**
 * The lossless export (issue #17).
 *
 * Checked by reading what it writes with `GeoJsonReader`, which was written for
 * the real catastro and knows nothing about this. That is what makes "lossless"
 * a claim with an independent witness rather than a comparison of the writer
 * with itself: if the two ever disagree about a property name, the row that
 * comes back is not the row that went out and this fails.
 */
final class GeoJsonWriterTest extends TestCase {
	/** Everything a Feature can carry, with nothing left null by accident. */
	private const FULL = [
		'externalId' => 'catastro:abc123',
		'name' => 'Junta de Vecinos Los Navegantes',
		'categorySlug' => 'organizacion',
		'subcategorySlug' => 'junta_vecinos',
		'geometry' => ['type' => 'Point', 'coordinates' => [-70.5811, -33.5211]],
		'locationQuality' => 'exacta',
		'address' => 'Los Navegantes 1234',
		'phone' => '+56 9 1234 5678',
		'email' => 'contacto@ejemplo.cl',
		'contactPerson' => 'Presidenta',
		'contactRole' => 'Presidenta',
		'openingHours' => 'Lunes a viernes, 9 a 17',
		'notes' => 'Entrada por el pasaje',
		'sourceRef' => 'Catastro municipal',
	];

	/**
	 * The same record as it reaches an export from an OSM-derived Dataset.
	 *
	 * `tools/boundary-features.php` stamps `source_es: OpenStreetMap` and a
	 * `source_url` on everything it produces (ADR-0004), and `GeoJsonReader`
	 * joins the two into `sourceRef` — which is the only thing an exported row
	 * knows about where it came from.
	 */
	private const FROM_OSM = 'OpenStreetMap — https://www.openstreetmap.org/way/101';

	/** @return array<string, mixed> */
	private static function osmRow(): array {
		// array_merge, not `+`: it keeps FULL's key ORDER, which the round-trip
		// assertions below compare with assertSame.
		return array_merge(self::FULL, ['sourceRef' => self::FROM_OSM]);
	}

	/**
	 * The same imported record after somebody rewrote the Fuente box.
	 *
	 * `sourceRef` IS that box (`src/components/FeatureDetail.vue`) and anybody may
	 * retype it. `official` is the row as the authority published it, written only
	 * by an import — `FeatureService::applyProvenance()` runs for a Provenance and
	 * a person's edit passes none (ADR-0003) — so it still names OpenStreetMap
	 * after the edit, and the geometry in the file is still OpenStreetMap's.
	 *
	 * @return array<string, mixed>
	 */
	private static function editedOsmRow(): array {
		return array_merge(self::FULL, [
			'sourceRef' => 'Municipalidad',
			'official' => json_encode(
				array_merge(self::FULL, ['sourceRef' => self::FROM_OSM]),
				JSON_UNESCAPED_UNICODE,
			),
		]);
	}

	/** @param list<array<string, mixed>> $rows */
	private function roundTrip(array $rows, bool $contacts = true): array {
		$json = (new GeoJsonWriter())->write($rows, $contacts);

		return (new GeoJsonReader())->read($json, 'catastro');
	}

	public function testEveryFieldSurvivesAReImport(): void {
		$back = $this->roundTrip([self::FULL]);

		self::assertCount(1, $back);
		// 'comuna' is what the FILE claims and only the UV cadastre claims it, so
		// it is not a property of the record and cannot round-trip.
		unset($back[0]['comuna']);
		self::assertSame(self::FULL, $back[0]);
	}

	/**
	 * The external id is what a re-import matches on, so it has to come back
	 * exactly — otherwise re-importing an export duplicates the whole Registry
	 * instead of updating it (ADR-0003).
	 */
	public function testTheExternalIdComesBackUnchanged(): void {
		$back = $this->roundTrip([self::FULL]);
		self::assertSame('catastro:abc123', $back[0]['externalId']);
	}

	/**
	 * A record with nothing but a name is a real record and must survive too.
	 *
	 * With one named exception, which is the reader's rule and not a loss here: a
	 * row that names no source takes the Dataset's slug as its source, so a
	 * record whose `sourceRef` was null comes back carrying the Dataset name.
	 * There is no way to say "no source" through the reader — an empty
	 * `source_es` folds to null and falls back the same way — and the cost is one
	 * spurious "Actualizado" the first time an export is re-imported, on records
	 * that had no source to begin with.
	 */
	public function testARecordWithOnlyANameSurvives(): void {
		$bare = [
			'externalId' => 'catastro:bare',
			'name' => 'Sin nada más',
			'categorySlug' => null,
			'subcategorySlug' => null,
			'geometry' => null,
			'locationQuality' => null,
			'address' => null,
			'phone' => null,
			'email' => null,
			'contactPerson' => null,
			'contactRole' => null,
			'openingHours' => null,
			'notes' => null,
			'sourceRef' => null,
		];

		$back = $this->roundTrip([$bare]);
		unset($back[0]['comuna']);

		self::assertSame('catastro', $back[0]['sourceRef'], 'the Dataset slug stands in for a missing source');
		unset($back[0]['sourceRef'], $bare['sourceRef']);
		self::assertSame($bare, $back[0]);
	}

	/**
	 * Without contact fields the file must not carry them at all.
	 *
	 * Not blanked — absent. A column of empty strings still says "this export
	 * was about these people", and the whole point of the unconfirmed export is
	 * that it carries nothing about anybody (ADR-0006).
	 */
	public function testWithoutContactsTheFieldsAreAbsentRatherThanEmpty(): void {
		$json = (new GeoJsonWriter())->write([self::FULL], false);
		$properties = json_decode($json, true)['features'][0]['properties'];

		foreach (['phone', 'email', 'contact_person', 'contact_role'] as $field) {
			self::assertArrayNotHasKey($field, $properties);
		}

		// And what is left is still a usable record.
		self::assertSame('Junta de Vecinos Los Navegantes', $properties['name']);
		self::assertSame('Los Navegantes 1234', $properties['address']);
	}

	/**
	 * …and the file says so, so that it cannot be read back as deletion.
	 *
	 * Absent fields and empty fields look identical to an import: it would match
	 * on the external id, see a phone number where the file has none, and clear
	 * it. The marker is how a file distinguishes "these records have no
	 * telephone" from "this file was not about telephones", which GeoJSON itself
	 * has no way to say.
	 */
	public function testAFileWrittenWithoutContactsSaysSoAndIsRefusedOnTheWayBack(): void {
		$json = (new GeoJsonWriter())->write([self::FULL], false);
		self::assertTrue(json_decode($json, true)[ContactFields::PARTIAL] ?? false);

		$this->expectException(InvalidImportException::class);
		(new GeoJsonReader())->read($json, 'catastro');
	}

	/** A geometry is written as GeoJSON says, not as a string of our own. */
	public function testTheGeometryIsWrittenWhereGeoJsonPutsIt(): void {
		$written = json_decode((new GeoJsonWriter())->write([self::FULL], true), true);

		self::assertSame('FeatureCollection', $written['type']);
		self::assertSame(
			['type' => 'Point', 'coordinates' => [-70.5811, -33.5211]],
			$written['features'][0]['geometry'],
		);
	}

	/**
	 * ODbL asks for the LICENCE to be named, not only the source (#28).
	 *
	 * At the top level rather than on each feature: RFC 7946 §6.1 allows foreign
	 * members on a FeatureCollection, the licence asks for one attribution and
	 * not one per row, and a property repeated on every feature would come back
	 * in on the next import as though somebody had typed it.
	 */
	public function testAnExportHoldingOsmDataNamesTheLicence(): void {
		$written = json_decode((new GeoJsonWriter())->write([self::osmRow()], true), true);

		self::assertArrayHasKey('license', $written);
		self::assertStringContainsString('OpenStreetMap', $written['license']);
		self::assertStringContainsString('ODbL', $written['license']);
		self::assertStringContainsString('https://www.openstreetmap.org/copyright', $written['license']);
	}

	/**
	 * And an export with nothing of OSM's in it does not say it has.
	 *
	 * A notice on every file would be a lie about the municipal catastro, and a
	 * standing lie is read as boilerplate — which is how the real one stops
	 * being noticed.
	 */
	public function testAnExportOfLocalRecordsCarriesNoLicence(): void {
		$written = json_decode((new GeoJsonWriter())->write([self::FULL], true), true);

		self::assertArrayNotHasKey('license', $written);
	}

	/**
	 * The notice must not cost the round trip (#28: it must not break a consumer).
	 *
	 * `GeoJsonReader` ignores top-level members it does not know — but "ignores"
	 * is exactly the kind of claim that stops being true the day somebody
	 * tightens the reader, and this is the export that goes back in.
	 */
	public function testTheLicenceDoesNotDisturbTheReImport(): void {
		$back = $this->roundTrip([self::osmRow()]);

		self::assertCount(1, $back);
		unset($back[0]['comuna']);
		self::assertSame(self::osmRow(), $back[0]);
	}

	/** Exporting nothing is an empty collection, not a broken file. */
	public function testAnEmptySetIsStillAValidFile(): void {
		$written = json_decode((new GeoJsonWriter())->write([], true), true);

		self::assertSame('FeatureCollection', $written['type']);
		self::assertSame([], $written['features']);
	}

	/**
	 * Rewriting Fuente must not drop the licence (#28).
	 *
	 * This is the failure the notice exists to prevent, and it would be invisible:
	 * the file is still full of OpenStreetMap's geometry and the line saying so
	 * has simply gone. `official` is the half of the signal a person cannot edit.
	 */
	public function testAnEditedFuenteDoesNotStripTheLicence(): void {
		$written = json_decode((new GeoJsonWriter())->write([self::editedOsmRow()], true), true);

		self::assertArrayHasKey('license', $written);
		self::assertStringContainsString('ODbL', $written['license']);
	}

	/**
	 * And the copy it reads that from never reaches the file.
	 *
	 * `official` is the whole published row, contact fields included. It rides in
	 * the export row only so the licence can be decided, and an export that
	 * withheld the telephone number in `properties` while carrying it inside a
	 * JSON blob would break exactly the promise ADR-0006 makes.
	 */
	public function testTheOfficialCopyNeverReachesTheFile(): void {
		$json = (new GeoJsonWriter())->write([self::editedOsmRow()], false);

		self::assertStringNotContainsString('official', $json);
		self::assertStringNotContainsString('contacto@ejemplo.cl', $json);
	}
}
