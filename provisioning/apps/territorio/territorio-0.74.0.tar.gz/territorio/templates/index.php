<?php
declare(strict_types=1);
/** SPA host page. The Vue app mounts on #territorio (script added in PageController). */
?>
<div id="territorio">
	<!-- aps-mount-loading stub — canonical fragment in MAPEO.md §5; Vue replaces the mount's children on boot. -->
	<div class="aps-mount-loading" role="status" aria-live="polite">Cargando…</div>
	<noscript><p class="aps-mount-noscript">Esta aplicación necesita JavaScript activado.</p></noscript>
</div>
