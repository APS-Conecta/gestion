<?php
declare(strict_types=1);
/** Admin settings host. Mounts on #territorio-admin (script added in AdminSettings::getForm). */
?>
<div id="territorio-admin">
	<!-- aps-mount-loading stub — canonical fragment in MAPEO.md §5; Vue replaces the mount's children on boot. -->
	<div class="aps-mount-loading" role="status" aria-live="polite">Cargando…</div>
	<noscript><p class="aps-mount-noscript">Esta aplicación necesita JavaScript activado.</p></noscript>
</div>
