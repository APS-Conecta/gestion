<?php

declare(strict_types=1);

namespace OCA\Territorio\Exception;

/** Thrown when what a person submitted is not a Feature this app will store. */
class InvalidFeatureException extends RefusedException {
}
