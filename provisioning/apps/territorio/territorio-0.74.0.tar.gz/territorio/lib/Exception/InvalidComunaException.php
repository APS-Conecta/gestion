<?php

declare(strict_types=1);

namespace OCA\Territorio\Exception;

/** Thrown when a CUT code offered for this install is not one this app will store. */
class InvalidComunaException extends RefusedException {
}
