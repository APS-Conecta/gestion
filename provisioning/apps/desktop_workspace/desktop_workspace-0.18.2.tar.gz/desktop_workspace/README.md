# Desktop Workspace for Nextcloud

A browser-contained **desktop workspace** for Nextcloud. Instead of juggling browser tabs, open
Nextcloud apps as draggable, resizable windows on a familiar desktop — with a taskbar or dock, a clock,
desktop icons, and an optional built-in file manager.

![Screenshot](screenshots/01-standard-light.png)

> **Status:** early development (0.x). Targets **Nextcloud 33–35**.

---

## Features

- **App windows** — open Nextcloud apps (Files, Mail, Calendar, …) as draggable, resizable,
  minimizable, maximizable windows. Snap to screen edges for tiling.
- **Taskbar or dock & clock** — choose a traditional taskbar or a centered bottom dock. Running windows and pinned apps follow the selected layout, and the clock/date stays in the shell controls.
- **Desktop icons** — show your **Favorites**, pinned apps, and/or the contents of a chosen **desktop folder**
  as icons, with drag-to-arrange positions, a recycling bin, and a home shortcut. Icons stay within the visible grid when the desktop is resized.
- **Drag-and-drop upload** — drop files from your computer onto the desktop to upload them into the
  desktop folder, with a progress bar.
- **Built-in file manager (experimental)** — *Desktop Files*, a lightweight in-shell file manager
  with a "+ New" menu, cut/copy/paste, rename, drag-and-drop, and a viewer that hands off to the
  native Nextcloud viewer.
- **Window & icon state is saved to your account** — open windows reopen where you left them (at
  their last location), and icon positions follow you across devices.
- **NC34-style Apps menu** — the Apps menu uses the same app symbols as Nextcloud 34, opens the native unified search overlay, can be resized upward/right, and remembers its size.
- **Header & account menu integration** — the Nextcloud header links open as Desktop Workspace
  windows; "Set status" and global search open as native overlays.
- **Per-user and per-admin settings** — including a first-visit onboarding, full per-user reset,
  and an admin "reset a single user" action.
- **Localized** — covers the Nextcloud language set where reliable translations are available.

---

## Requirements

- Nextcloud **33**, **34**, or **35**
- A standard Nextcloud app environment (PHP per the Nextcloud 33 requirements)

### Compatibility smoke matrix

Run the app against disposable, isolated Nextcloud 33, 34, and 35 containers:

```bash
./scripts/test-desktop-workspace-matrix
```

The matrix uses pinned Nextcloud 33.0.8 and 34.0.2 images plus the local checksum-pinned NC35 development image. For each major version it installs Desktop Workspace, creates a normal test user, verifies the shell and dynamic-data routes, confirms that a personal-settings request without a CSRF token is rejected, saves the setting with a valid token, confirms that the normal user is denied access to an administrator route, and confirms that the administrator can use that route. Run-specific container names make concurrent runs safe, and containers plus their anonymous volumes are removed automatically; set `KEEP_CONTAINERS=1` to retain them for debugging or `MATRIX_MAJORS="34 35"` to run a subset. Image environment variables can override the pinned defaults.

---

## Installation

### From the Nextcloud app installer (recommended)

Desktop Workspace is available directly from the Nextcloud App Store. In Nextcloud, open **Apps**,
select the **Customization** category, find **Desktop Workspace**, and select **Download and enable**.

### From a release tarball

1. Download the latest `desktop_workspace-<version>.tar.gz`.
2. Extract it into your Nextcloud `custom_apps/` (or `apps/`) directory so the path is
   `…/custom_apps/desktop_workspace/`.
3. Enable the app:
   ```bash
   occ app:enable desktop_workspace
   ```
4. Open **Desktop Workspace** from the app navigation.

### From source

```bash
git clone <this-repo> desktop_workspace
cd desktop_workspace
make            # builds build/appstore/desktop_workspace-<version>.tar.gz
```

Place the resulting `desktop_workspace` folder in your Nextcloud apps directory and enable it as above.

---

## Configuration

### Personal settings (per user)

**Settings → Desktop**. Changes apply immediately:

- **Desktop icons** — show favorites, recycling bin, home folder; confirmation prompts.
- **Desktop folder** — pick a folder you own to show on the desktop.
- **Wallpaper** — jump to Nextcloud's appearance settings.
- **Window controls** — place title-bar controls on the left or right.
- **Desktop panel** — switch between the taskbar and dock layouts.
- **Experimental** — opt in to the *Desktop Files* manager (if enabled by the admin).
- **Reset** — reset icon positions, reset open windows, or **reset all desktop settings** (as if
  the desktop had never been opened).

### Admin settings

**Administration settings → Desktop Workspace**:

- Enable/disable the **experimental Desktop Files** manager (optionally per group).
- Configure **multiple-window** behavior per app.
- **Debug logging** to a log file.
- **Reset a single user's** desktop settings completely.
- Basic **usage stats** (unique users per day/week).

### Early planning: decoration and icon-theme access

For the full release, the project is exploring whether the optional **decoration styles and icon themes only** might require an unlock on instances with more than 10 active users. Instances with 10 or fewer active users would keep those appearance choices unlocked, while larger instances could receive an unlock code by supporting the project.

This is an early planning and exploration notice, not implemented behavior. There is currently no lock, unlock-code system, or supporter check. The taskbar/dock choice and the left/right window-control choice are not part of this plan.

---

## Like Desktop Workspace?

If you find the app useful, please [rate Desktop Workspace in the Nextcloud App Store](https://apps.nextcloud.com/apps/desktop_workspace).

---

## License

Licensed under the **GNU Affero General Public License v3.0 or later** (AGPL-3.0-or-later), in line
with Nextcloud apps.
